<?php
$hostname = 'localhost';
$username = 'root'; // 데이터베이스 사용자 이름
$password = ''; // 데이터베이스 비밀번호
$database = 'teamgo'; // 데이터베이스 이름

$conn = new mysqli($hostname, $username, $password, $database);

if ($conn->connect_error) {
    die("데이터베이스 연결 실패: " . $conn->connect_error);
} else {
    //echo "데이터베이스에 성공적으로 연결되었습니다!";
}
?>