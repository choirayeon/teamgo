<?php
include_once 'config.php'; // 카카오 API 설정 파일 포함

// 데이터베이스 연결 설정
$servername = "localhost"; // 서버 이름
$username = "root"; // 데이터베이스 사용자 이름
$password = ""; // 데이터베이스 비밀번호
$dbname = "brandzipstage"; // 데이터베이스 이름

// 데이터베이스 연결
$conn = new mysqli($servername, $username, $password, $dbname);

// 연결 확인
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// 결과 초기화
$res = array('rst' => 'fail', 'code' => (__LINE__ * -1), 'msg' => '');

try {
    // 카카오 API로부터 전달된 인증 코드와 state 값 확인
    if (empty($_GET['code']) || empty($_GET['state']) || $_GET['state'] != $_COOKIE['state']) {
        throw new Exception("인증 실패", (__LINE__ * -1));
    }

    // 토큰 요청 URL 구성
    $replace = array(
        '{grant_type}' => 'authorization_code',
        '{client_id}' => $kakaoConfig['client_id'],
        '{redirect_uri}' => $kakaoConfig['redirect_uri'],
        '{client_secret}' => $kakaoConfig['client_secret'],
        '{code}' => $_GET['code']
    );
    $login_token_url = str_replace(array_keys($replace), array_values($replace), $kakaoConfig['login_token_url']);
    $response = curl_kakao($login_token_url);

    // 응답 확인
    $token_data = json_decode($response);
    if (empty($token_data)) {
        throw new Exception("토큰 요청 실패", (__LINE__ * -1));
    }
    if (!empty($token_data->error) || empty($token_data->access_token)) {
        throw new Exception("토큰 인증 에러", (__LINE__ * -1));
    }

    // 사용자 정보 요청
    $header = array("Authorization: Bearer " . $token_data->access_token);
    $profile_url = $kakaoConfig['profile_url'];
    $profile_response = curl_kakao($profile_url, $header);
    $profile_data = json_decode($profile_response);

    if (empty($profile_data) || empty($profile_data->id)) {
        throw new Exception("프로필 요청 실패", (__LINE__ * -1));
    }

    $user_id = $profile_data->id; // 카카오 계정의 고유 ID

    // 데이터베이스에서 사용자 조회
    $sql = "SELECT * FROM user WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // 기존 회원인 경우 로그인 처리 (세션 설정)
        $chk = $result->fetch_object();

        if ($chk->type != 3) {
            echo "<script>alert('접근 권한이 없습니다. 교수 계정으로 로그인하세요.');</script>";
            echo "<script>location.replace('http://localhost/teamgoadmin/application/views/admin/login_admin.php');</script>";
            exit;
        }

        // 기존 회원의 'name'과 'nickname' 설정
        $name = $chk->name;
        $nickname = $chk->nickname;
    } else {
        // 신규 회원인 경우 가입 처리 후 로그인
        $name = $profile_data->properties->nickname ?? '카카오사용자';
        $nickname = $profile_data->properties->nickname ?? '카카오사용자';
        $sql_insert = "INSERT INTO user (id, name, nickname) VALUES (?, ?, ?)";
        $stmt_insert = $conn->prepare($sql_insert);
        $stmt_insert->bind_param("sss", $user_id, $name, $nickname);
        $stmt_insert->execute();
        $chk = (object) array('num' => $stmt_insert->insert_id);
        $stmt_insert->close();
    }

    // 세션 설정 (로그인 처리)
    session_start();
    $_SESSION['id'] = $user_id;
    $_SESSION['name'] = $name; // 기존 회원의 name을 세션에 설정
    $_SESSION['nickname'] = $nickname;
    $_SESSION['num'] = $chk->num;

    $res['rst'] = 'success';
} catch (Exception $e) {
    $res['msg'] = $e->getMessage();
    $res['code'] = $e->getCode();
}

// 결과에 따른 처리
if ($res['rst'] == 'success') {
    // 성공 시 알림 메시지 출력 후 리다이렉트
    echo "<script>alert('로그인하셨습니다.');</script>";
    echo "<script>location.replace('http://localhost/teamgoadmin/application/views/admin/main_info_admin.php');</script>";
    exit();
} else {
    // 실패 시 JSON 응답 출력
    echo json_encode($res);
}

// state 초기화
setcookie('state', '', time() - 3600);

// cURL을 사용하여 카카오 API 호출
function curl_kakao($url, $header = null)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    if ($header !== null) {
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
    }
    $response = curl_exec($ch);
    curl_close($ch);
    return $response;
}

// 데이터베이스 연결 종료
$conn->close();
