<?php
session_cache_expire(360);
session_start();

if (!isset($_SESSION['id'])) {
    echo "<script>alert('로그인 후 이용해 주세요.');</script>";
    echo "<script>location.replace('../admin/login_admin.php');</script>";
    exit;
}

include "../../config/db_connect.php";

// 페이지네이션 설정
$itemsPerPage = 6;

// 리드팀플 페이지네이션
$leadPage = isset($_GET['lead_page']) ? (int)$_GET['lead_page'] : 1;
$leadPage = ($leadPage < 1) ? 1 : $leadPage;
$leadOffset = ($leadPage - 1) * $itemsPerPage;

// 팀플룸 페이지네이션
$teamplePage = isset($_GET['teample_page']) ? (int)$_GET['teample_page'] : 1;
$teamplePage = ($teamplePage < 1) ? 1 : $teamplePage;
$teampleOffset = ($teamplePage - 1) * $itemsPerPage;

// 리드팀플 검색 기능
$leadSearchQuery = '';
if (isset($_GET['lead_search']) && !empty($_GET['lead_search'])) {
    $leadSearch = mysqli_real_escape_string($conn, $_GET['lead_search']);
    $leadSearchQuery = "WHERE name LIKE '%$leadSearch%'";
}

// 팀플룸 검색 기능
$teampleSearchQuery = '';
if (isset($_GET['teample_search']) && !empty($_GET['teample_search'])) {
    $teampleSearch = mysqli_real_escape_string($conn, $_GET['teample_search']);
    $teampleSearchQuery = "WHERE t.name LIKE '%$teampleSearch%'";
}

// 리드팀플 전체 레코드 수 구하기
$leadTotalQuery = "SELECT COUNT(num) AS total FROM lead_teample $leadSearchQuery";
$leadTotalResult = $conn->query($leadTotalQuery);
$leadTotalCount = $leadTotalResult->fetch_assoc()['total'];

// 리드팀플 총 페이지 수
$leadTotalPages = ceil($leadTotalCount / $itemsPerPage);

// 팀플룸 전체 레코드 수 구하기
$teampleTotalQuery = "SELECT COUNT(t.num) AS total FROM teample t $teampleSearchQuery";
$teampleTotalResult = $conn->query($teampleTotalQuery);
$teampleTotalCount = $teampleTotalResult->fetch_assoc()['total'];

// 팀플룸 총 페이지 수
$teampleTotalPages = ceil($teampleTotalCount / $itemsPerPage);

// 리드팀플 목록을 가져오는 쿼리
$leadTeamQuery = "
    SELECT lt.num, lt.name, COUNT(ltm.teample) AS isActive, lt.createdAt
    FROM lead_teample lt
    LEFT JOIN lead_teample_member ltm ON lt.num = ltm.teample
    $leadSearchQuery
    GROUP BY lt.num, lt.name, lt.createdAt
    LIMIT $leadOffset, $itemsPerPage
";
$leadTeamResult = $conn->query($leadTeamQuery);


// 팀플룸 목록을 가져오는 쿼리
$teampleQuery = "
    SELECT t.num, t.name, COUNT(tm.teample) AS isActive, t.createdAt, lt.name AS lead_teample
    FROM teample t
    LEFT JOIN teample_member tm ON t.num = tm.teample
    LEFT JOIN lead_teample lt ON t.lead_teample = lt.num
    $teampleSearchQuery
    GROUP BY t.num, t.name, t.createdAt, lt.name
    LIMIT $teampleOffset, $itemsPerPage
";
$teampleResult = $conn->query($teampleQuery);

// 페이지네이션 링크 생성 함수
function createPaginationLinks($totalPages, $currentPage, $pageParam, $searchParam)
{
    $paginationLinks = '';

    if ($totalPages > 1) {
        if ($currentPage > 1) {
            $paginationLinks .= "<a style='color: blue; text-decoration: none; padding: 5px 10px;' href=\"?{$pageParam}=1&{$searchParam}=" . urlencode($_GET[$searchParam] ?? '') . "\">처음</a>&nbsp;";
            $paginationLinks .= "<a style='color: blue; text-decoration: none; padding: 5px 10px;' href=\"?{$pageParam}=" . ($currentPage - 1) . "&{$searchParam}=" . urlencode($_GET[$searchParam] ?? '') . "\">이전</a>&nbsp;";
        }

        $pageTerm = 5;
        $startPage = $currentPage - $pageTerm;
        if ($startPage < 1) {
            $startPage = 1;
        }
        $lastPage = $currentPage + $pageTerm;
        if ($lastPage > $totalPages) {
            $lastPage = $totalPages;
        }

        for ($i = $startPage; $i <= $lastPage; $i++) {
            $isActive = ($i == $currentPage) ? 'style="color: black; text-decoration: underline; font-weight: bold; padding: 5px 10px;"' : 'style="color: black; text-decoration: none; padding: 5px 10px;"';
            $paginationLinks .= "&nbsp;<a href=\"?{$pageParam}=$i&{$searchParam}=" . urlencode($_GET[$searchParam] ?? '') . "\" $isActive>$i</a>&nbsp;";
        }

        if ($currentPage < $totalPages) {
            $paginationLinks .= "<a style='color: blue; text-decoration: none; padding: 5px 10px;' href=\"?{$pageParam}=" . ($currentPage + 1) . "&{$searchParam}=" . urlencode($_GET[$searchParam] ?? '') . "\">다음</a>&nbsp;";
            $paginationLinks .= "<a style='color: blue; text-decoration: none; padding: 5px 10px;' href=\"?{$pageParam}=$totalPages&{$searchParam}=" . urlencode($_GET[$searchParam] ?? '') . "\">끝</a>";
        }
    }

    return $paginationLinks;
}


// 리드팀플 페이지네이션 링크 생성
$leadPaginationLinks = createPaginationLinks($leadTotalPages, $leadPage, 'lead_page', 'lead_search');

// 팀플룸 페이지네이션 링크 생성
$teamplePaginationLinks = createPaginationLinks($teampleTotalPages, $teamplePage, 'teample_page', 'teample_search');
?>

<style>
    .active-page {
        color: blue;
        font-weight: bold;
        text-decoration: none;
    }
</style>
<!-- HTML 시작 -->
<!DOCTYPE html>
<html lang="ko">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>teamgo</title>
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet">
    <link href="/teamgoadmin/css/styles.css" rel="stylesheet">
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    <style>
        .table-container {
            margin-bottom: 20px;
            width: 90%;
            max-width: 1200px;
            margin: 20px auto;
        }

        .btn {
            font-size: 13px;
        }

        .table {
            font-size: 13px;
        }
        .table th,
        .table td {
            padding: 8px;
        }
            /* 테이블 전체의 배경색을 연초록색으로 설정 */
        .table {
            background-color: #D7EDCE; /* 연초록색 */
        }
        /* 테이블 배경색 */
        .table-custom {
         background-color: #D7EDCE; /* 연초록색 */
        }
    /* 테이블 헤더의 배경색을 다소 어두운 초록색으로 설정 */
        .table thead th {
            background-color: #E3B030; /* 다소 어두운 연초록색 */
            color: #5C450A; /* 글자 색상 */
        }

    /* 테이블 셀의 기본 배경색 설정 (선택 사항) */
        .table td {
            background-color: #FFF7EB; /* 연초록색 */
        }

            /* 연초록색 버튼 스타일 */
    .btn-custom-green {
        background-color: #9C7513; /* 연초록색 */
        border-color: #9C7513; /* 테두리 색상 */
        color: #fff; /* 글자 색상 */
    }

    .btn-custom-green:hover {
        background-color: #45a049; /* 마우스 오버 시 색상 */
        border-color: #45a049; /* 테두리 색상 */
    }

    .btn-custom-search {
        background-color: #163382; /* 버튼 배경색 (초록색) */
        border-color: #163382; /* 버튼 테두리 색상 */
        color: #fff; /* 버튼 텍스트 색상 */
        padding: 4px 15px; /* 버튼의 패딩 */
        border-radius: 5px; /* 버튼의 모서리 둥글기 */
        font-size: 16px; /* 버튼 텍스트 크기 */
    }

    .btn-custom-search:hover {
        background-color: #163382; /* 버튼 호버 시 배경색 */
        border-color: #163382; /* 버튼 호버 시 테두리 색상 */
    }



</style>
    </style>
</head>

<body class="sb-nav-fixed">
    <?php include $_SERVER['DOCUMENT_ROOT'] . '/teamgoadmin/application/views/include/top_menu.php'; ?>

    <div id="layoutSidenav">
        <?php include $_SERVER['DOCUMENT_ROOT'] . '/teamgoadmin/application/views/include/side_menu.php'; ?>
        <div id="layoutSidenav_content" style="padding-top: 0px; height: auto; background-color: rgb(224, 224, 224);">
            <main>
                <!-- 리드팀플 목록 -->
                <div style="width: 100%; display: flex; flex-direction: column; align-items: center;">
                    <div style="width: 100%; margin-bottom: 20px;">
                        <div class="card shadow">
                            <div class="card-body">
                                <h4>리드팀플 목록</h4>
                            </div>
                            <div>
                                <form method="GET" action="" style="display: flex; align-items: center;">
                                    <input type="text" name="lead_search" placeholder="리드팀플룸 이름으로 검색" value="<?= htmlspecialchars($_GET['lead_search'] ?? '') ?>" style="padding: 13px; margin-right: 10px; width: 500px;">
                                    <button type="submit" class="btn btn-custom-search">검색</button>
                                    <button type="button" onclick="window.location.href='main_team_admin.php';" class="btn btn-secondary" style="margin-left: 10px;">초기화</button>
                                </form>
                                <!-- 리드팀플 목록 테이블 -->
                                        <div class="card-body">
                                            <table class="table table-bordered">
                                                <thead>
                                                    <tr>
                                                        <th>번호</th>
                                                        <th>리드팀플룸 이름</th>
                                                        <th>인원</th>
                                                        <th>생성일</th>
                                                        <th>보기</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    if ($leadTeamResult->num_rows > 0) {
                                                        $index = 1;
                                                        while ($room = $leadTeamResult->fetch_assoc()) {
                                                            echo "<tr>";
                                                            echo "<td>" . ($index++) . "</td>";
                                                            echo "<td>{$room['name']}</td>";
                                                            echo "<td>{$room['isActive']}</td>";
                                                            echo "<td>" . date("Y-m-d", strtotime($room['createdAt'])) . "</td>";
                                                            echo "<td><a href='progress.php?team_id=" . (isset($room['num']) ? $room['num'] : '#') . "' class='btn btn-custom-green btn-sm'>보기</a></td>";
                                                            echo "</tr>";
                                                        }
                                                    } else {
                                                        echo "<tr><td colspan='5'>리드플룸 데이터가 없습니다.</td></tr>";
                                                    }
                                                    ?>
                                                </tbody>
                                            </table>
                                <!-- 리드팀플 페이지네이션 -->
                                <div class="pagination">
                                    <?php echo $leadPaginationLinks; ?>
                                </div>
                            </div>
                                        </div>
                                    </div>
                            <!-- 팀플룸 목록 -->
                            <div style="width: 100%; display: flex; flex-direction: column; align-items: center;">
                                <div style="width: 100%; margin-bottom: 20px;">
                                    <div class="card" style="box-shadow: none;">
                                        <div class="card-body">
                                            <h4>팀플룸 목록</h4>
                                        </div>
                                        <div>
                                            <form method="GET" action="" style="display: flex; align-items: center;">
                                                <input type="text" name="teample_search" placeholder="팀플룸 이름으로 검색" value="<?= htmlspecialchars($_GET['teample_search'] ?? '') ?>" style="padding: 13px; margin-right: 10px; width: 500px;">
                                                <button type="submit" class="btn btn-custom-search">검색</button>
                                                <button type="button" onclick="window.location.href='main_team_admin.php';" class="btn btn-secondary" style="margin-left: 10px;">초기화</button>
                                                <button type="button" class="btn btn-success" onclick="submitTeampleForm()" style="margin-left: 10px;">선택 보기</button>
                                            </form>
                                            <!-- 팀플룸 목록 테이블 -->
                                            <form id="teampleForm" method="POST" action="teampleprogress.php">
                                                <div class="card-body">
                                                <table class="table table-bordered">
                                                    <thead>
                                                        <tr>
                                                            <th>번호</th>
                                                            <th>선택</th>
                                                            <th>팀플룸 이름</th>
                                                            <th>인원</th>
                                                            <th>생성일</th>
                                                            <th>멀티팀플명</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php
                                                        if ($teampleResult->num_rows > 0) {
                                                            $index = 1;
                                                            while ($room = $teampleResult->fetch_assoc()) {
                                                                echo "<tr>";
                                                                echo "<td>" . ($index++) . "</td>";
                                                                $roomId = isset($room['num']) ? $room['num'] : '';
                                                                echo "<td><input type='checkbox' name='selected_teample[]' value='{$roomId}' /></td>";
                                                                echo "<td>{$room['name']}</td>";
                                                                echo "<td>{$room['isActive']}</td>";
                                                                echo "<td>" . date("Y-m-d", strtotime($room['createdAt'])) . "</td>";
                                                                echo "<td>{$room['lead_teample']}</td>";
                                                                echo "</tr>";
                                                            }
                                                        } else {
                                                            echo "<tr><td colspan='6'>팀플룸 데이터가 없습니다.</td></tr>";
                                                        }
                                                        ?>
                                                    </tbody>
                                                </table>
                                    <!-- 팀플룸 페이지네이션 -->
                                    <div class="pagination">
                                        <?php echo $teamplePaginationLinks; ?>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                            <script>
                                // 선택된 체크박스를 가진 폼 제출 함수
                                function submitTeampleForm() {
                                    const form = document.getElementById('teampleForm');
                                    const checkboxes = form.querySelectorAll('input[name="selected_teample[]"]:checked');

                                    if (checkboxes.length === 0) {
                                        alert('최소 하나의 팀플룸을 선택해 주세요.');
                                    } else {
                                        form.submit(); // 폼 제출
                                    }
                                }
                            </script>
                        </div>
                    </div>
            </main>
        </div>
    </div>
    </div>    
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script>
</body>

</html>