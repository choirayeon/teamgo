<?php
session_start();

if (!isset($_SESSION['id'])) {
    echo "<script>alert('로그인 후 이용해 주세요.');</script>";
    echo "<script>location.replace('../admin/login_admin.php');</script>";
    exit;
}

include "../../config/db_connect.php";

$id = $_SESSION['id'];
$name = $_POST['name'];
$nickname = $_POST['nickname'];

$stmt = $conn->prepare("UPDATE user SET name = ?, nickname = ? WHERE id = ?");
$stmt->bind_param("sss", $name, $nickname, $id);

if ($stmt->execute()) {
    echo "<script>alert('정보가 성공적으로 수정되었습니다.');</script>";
    echo "<script>location.replace('../admin/main_info_admin.php');</script>";
} else {
    echo "<script>alert('정보 수정에 실패했습니다.');</script>";
    echo "<script>history.back();</script>";
}

$stmt->close();
$conn->close();
?>