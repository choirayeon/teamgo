<?php
session_cache_expire(360);
session_start();

if (isset($_SESSION['id'])) {
    echo "<script>alert(\"이미 로그인 하셨습니다.\");</script>";
    echo "<script>location.replace('../admin/main_info_admin.php');</script>";
    exit;
}

include "../../config/db_connect.php";

$root = $_SERVER['CONTEXT_PREFIX'] ?? '/';

$id = $_POST['id'];
$pw = $_POST['pw'];

$stmt = $conn->prepare("SELECT * FROM user WHERE id = ?");
$stmt->bind_param("s", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $info = $result->fetch_assoc();

    if (password_verify($pw, $info['password'])) {
        if ($info['type'] === 3) {
            $_SESSION['id'] = $id;
            $_SESSION['name'] = $info['name'];
            $_SESSION['type'] = $info['type'];

            echo "<script>alert('로그인하셨습니다.');</script>";
            echo "<script>location.replace('../admin/main_info_admin.php');</script>";
            exit;
        } else {
            echo "<script>alert('접근 권한이 없습니다. 교수 계정으로 로그인하세요.');</script>";
            echo "<script>location.replace('../admin/login_admin.php');</script>";
            exit;
        }
    } else {
        echo "<script>alert('이메일 혹은 비밀번호가 맞지 않습니다.\\nteamgo.kr에서 계정을 확인해 주세요.');</script>";
        echo "<script>location.replace('login_admin.php');</script>";
        exit;
    }
} else {
    echo "<script>alert('이메일 혹은 비밀번호가 맞지 않습니다.\\nteamgo.kr에서 계정을 확인해 주세요.');</script>";
    echo "<script>location.replace('login_admin.php');</script>";
    exit;
}

$conn->close();
