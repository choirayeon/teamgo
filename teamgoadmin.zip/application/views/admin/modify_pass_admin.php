<?php
session_cache_expire(360);
session_start();

if (!isset($_SESSION['id'])) {
    echo "<script>alert('로그인 후 이용해 주세요.');</script>";
    echo "<script>location.replace('../admin/login_admin.php');</script>";
    exit;
}

include "../../config/db_connect.php";

$id = $_SESSION['id'];
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $password = $_POST['pwd'] ?? '';
    $password_confirm = $_POST['pwd2'] ?? '';

    if (empty($password)) {
        $errors['pwd'] = '비밀번호를 입력해 주세요.';
    } elseif (strlen($password) < 8 || strlen($password) > 20 || !preg_match('/^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,20}$/', $password)) {
        $errors['pwd'] = '비밀번호는 영문자와 숫자를 포함하여 8~20자 사이여야 합니다.';
    }

    if ($password !== $password_confirm) {
        $errors['pwd2'] = '비밀번호가 일치하지 않습니다.';
    }

    if (empty($errors)) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        $stmt = $conn->prepare("UPDATE user SET password = ? WHERE id = ?");
        $stmt->bind_param("ss", $hashed_password, $id);

        if ($stmt->execute()) {
            echo "<script>alert('비밀번호가 성공적으로 수정되었습니다.');</script>";
            echo "<script>location.replace('../admin/main_info_admin.php');</script>";
            exit;
        } else {
            $errors['general'] = '비밀번호 수정에 실패했습니다.';
        }

        $stmt->close();
    }
}

$stmt = $conn->prepare("SELECT * FROM user WHERE id = ?");
$stmt->bind_param("s", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $user_info = $result->fetch_assoc();
} else {
    echo "<script>alert('사용자 정보를 가져올 수 없습니다.');</script>";
    exit;
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="ko">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>teamgo</title>
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet">
    <link href="/teamgoadmin/css/styles.css" rel="stylesheet">
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
</head>

<body class="sb-nav-fixed">
    <?php include $_SERVER['DOCUMENT_ROOT'] . '/teamgoadmin/application/views/include/top_menu.php'; ?>

    <div id="layoutSidenav">
        <?php include $_SERVER['DOCUMENT_ROOT'] . '/teamgoadmin/application/views/include/side_menu.php'; ?>

        <div id="layoutSidenav_content" style="padding-top: 20px; height: auto; background-color: rgb(224, 224, 224);">
            <main>
                <div style="width:600px;">
                    <div class="card shadow">
                        <div class="card-body">
                            <form action="" method="post">
                                <table class="table table-bordered">
                                    <tr>
                                        <td>사용자 유형</td>
                                        <td>
                                            <input type="text" name="user_type" class="form-control" readonly="true" style="background: #D1D1D1;" value="교수" />
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>아이디</td>
                                        <td>
                                            <input type="text" name="id" id="id" class="form-control" readonly="true" style="background: #D1D1D1;" value="<?php echo htmlspecialchars($user_info['id']); ?>" />
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>이름</td>
                                        <td>
                                            <input type="text" name="name" id="name" class="form-control" readonly="true" style="background: #D1D1D1;" value="<?php echo htmlspecialchars($user_info['name']); ?>" />
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>닉네임</td>
                                        <td>
                                            <input type="text" name="nickname" class="form-control" readonly="true" style="background: #D1D1D1;" value="<?php echo htmlspecialchars($user_info['nickname']); ?>" />
                                        </td>
                                    </tr>
                                </table>

                                <div class="form-group">
                                    <label for="pwd">비밀번호</label>
                                    <input type="password" name="pwd" id="pwd" class="form-control" />
                                    <?php if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($errors['pwd'])): ?>
                                        <div style='color:red'><?php echo $errors['pwd']; ?></div>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="pwd2">비밀번호 확인</label>
                                    <input type="password" name="pwd2" id="pwd2" class="form-control" />
                                    <?php if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($errors['pwd2'])): ?>
                                        <div style='color:red'><?php echo $errors['pwd2']; ?></div>
                                    <?php endif; ?>
                                </div>

                                <?php if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($errors['general'])): ?>
                                    <div style='color:red'><?php echo $errors['general']; ?></div>
                                <?php endif; ?>

                                <button type="submit" class="btn btn-secondary" style="margin-right: 10px;">비밀번호 변경하기</button>
                            </form>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script>
</body>

</html>