<?php
if ($_POST['action'] == 'view_selected' && !empty($_POST['selected_teampl'])) {
    $selectedTeamplIds = implode(",", $_POST['selected_teampl']); // 선택된 팀플룸 ID 배열을 문자열로 변환

    // 선택된 팀플룸의 진행도를 조회하는 SQL 쿼리 작성
    $query = "SELECT * FROM team_progress WHERE room_id IN ($selectedTeamplIds)";
    $result = mysqli_query($conn, $query);

    // 조회한 결과를 표시하는 코드
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<p>팀플룸: {$row['room_name']} | 진행도: {$row['progress']}%</p>";
    }
} else {
    echo "선택된 팀플룸이 없습니다.";
}
?>
