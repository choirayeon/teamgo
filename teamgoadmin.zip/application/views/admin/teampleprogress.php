<?php
session_cache_expire(360);
session_start();

if (!isset($_SESSION['id'])) {
    echo "<script>alert('로그인 후 이용해 주세요.');</script>";
    echo "<script>location.replace('../admin/login_admin.php');</script>";
    exit;
}

include "../../config/db_connect.php";

$id = $_SESSION['id'];

// 사용자 정보 가져오기
$stmt = $conn->prepare("SELECT * FROM user WHERE id = ?");
$stmt->bind_param("s", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $user_info = $result->fetch_assoc();
} else {
    echo "<script>alert('사용자 정보를 가져올 수 없습니다.');</script>";
    exit;
}

// 선택된 팀플룸 ID 가져오기
$selectedTeample = isset($_POST['selected_teample']) ? $_POST['selected_teample'] : [];

if (empty($selectedTeample)) {
    echo "<script>alert('선택된 팀플룸이 없습니다.');</script>";
    exit;
}

$team_ids = implode(',', array_map('intval', $selectedTeample)); // 선택된 팀플룸 ID들을 쉼표로 구분하여 문자열로 변환

$query = "
    SELECT 
        t.name AS teample_name, 
        (SELECT COUNT(*) FROM teample_member WHERE teample = t.num) AS members_count,
        t.count AS target_tasks, 
        (SELECT COUNT(*) FROM task WHERE teample = t.num) AS progress,
        (SELECT COUNT(*) FROM task WHERE teample = t.num) / t.count * 100 AS progress_rate,
        t.score AS target_score, 
        t.current_progress AS current_score,
        (t.current_progress / t.score) * 100 AS score_rate
    FROM teample t
    WHERE t.num IN ($team_ids)  -- 선택된 팀플룸의 ID를 조건에 추가
";
$result_teample = $conn->query($query);

?>

<!DOCTYPE html>
<html lang="ko">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Teamgo - Progress</title>
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet">
    <link href="/teamgoadmin/css/styles.css" rel="stylesheet">
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
    <style>
        .sortable:hover {
            cursor: pointer;
            text-decoration: underline;
        }

        .sort-icon {
            margin-left: 5px;
            font-size: 12px;
        }
    </style>
</head>

<body class="sb-nav-fixed">
    <?php include $_SERVER['DOCUMENT_ROOT'] . '/teamgoadmin/application/views/include/top_menu.php'; ?>
    <div id="layoutSidenav">
        <?php include $_SERVER['DOCUMENT_ROOT'] . '/teamgoadmin/application/views/include/side_menu.php'; ?>

        <div id="layoutSidenav_content" style="padding-top: 20px; height: auto; background-color: rgb(224, 224, 224);">
            <main>
                <button id="showTable" onclick="showTable()" class="btn btn-primary" style="background: #2C3E50; border:#2C3E50;">표 보기</button>
                <button id="showGraph" onclick="showGraph()" class="btn btn-primary" style="background: #2C3E50; border:#2C3E50;">그래프 보기</button>

                <div id="tableContainer" style="width: 100%; margin-bottom: 40px; display: block;">
                    <div class="card shadow">
                        <div class="card-body">
                            <table class="table table-bordered" id="teamTable">
                                <thead>
                                    <tr>
                                        <th>번호</th>
                                        <th class="sortable" onclick="sortTable(1, this)">팀플룸 이름 <i class="fas fa-sort sort-icon"></i></th>
                                        <th>인원</th>
                                        <th>목표 테스크 수</th>
                                        <th class="sortable" onclick="sortTable(4, this)">진행도 <i class="fas fa-sort sort-icon"></i></th>
                                        <th>횟수 달성율(%)</th>
                                        <th>목표 점수</th>
                                        <th class="sortable" onclick="sortTable(7, this)">현 점수 <i class="fas fa-sort sort-icon"></i></th>
                                        <th>점수 달성율</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php
                                    if ($result_teample->num_rows > 0) {
                                        $index = 1;
                                        while ($row = $result_teample->fetch_assoc()) {
                                            echo "<tr>";
                                            echo "<td>" . ($index++) . "</td>";
                                            echo "<td>{$row['teample_name']}</td>";
                                            echo "<td>{$row['members_count']}</td>";
                                            echo "<td>{$row['target_tasks']}</td>";
                                            echo "<td>{$row['progress']}</td>";
                                            echo "<td>" . number_format($row['progress_rate'], 2) . "%</td>";
                                            echo "<td>{$row['target_score']}</td>";
                                            echo "<td>{$row['current_score']}</td>";
                                            echo "<td>" . number_format($row['score_rate'], 2) . "%</td>";
                                            echo "</tr>";
                                        }
                                    } else {
                                        echo "<tr><td colspan='9'>선택된 팀플룸 데이터가 없습니다</td></tr>";
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div id="graphContainer" style="width: 100%; height: 800px; display: none;">
                    <!-- 그래프 영역 -->
                    <canvas id="progressChart" style="width: 500px; height: 80px;"></canvas>
                    <canvas id="scoreChart" style="margin-top: 50px; width: 500px; height: 80px;"></canvas>
                </div>
                <button onclick="location.href='/teamgoadmin/application/views/admin/main_team_admin.php'" class="btn btn-primary" style="background: #2C3E50; border:#2C3E50;">확인</button>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script>

    <script>
        function showTable() {
            document.getElementById('tableContainer').style.display = 'block';
            document.getElementById('graphContainer').style.display = 'none';
        }

        function showGraph() {
            document.getElementById('tableContainer').style.display = 'none';
            document.getElementById('graphContainer').style.display = 'block';
            drawCharts();
        }

        function drawCharts() {
        var ctx1 = document.getElementById('progressChart').getContext('2d');
        var ctx2 = document.getElementById('scoreChart').getContext('2d');

        // 첫 번째 차트: 횟수 달성율
        var progressChart = new Chart(ctx1, {
            type: 'horizontalBar',
            data: {
                labels: [<?php
                            // 그래프용 팀 이름 가져오기
                            $names = [];
                            foreach ($result_teample as $row) {
                                $names[] = "'{$row['teample_name']}'";
                            }
                            echo implode(',', $names);
                        ?>],
                datasets: [{
                    label: '횟수 달성율 (%)',
                    data: [<?php
                            // 그래프용 진행률 가져오기
                            $progress_rates = [];
                            foreach ($result_teample as $row) {
                                $progress_rates[] = $row['progress_rate'];
                            }
                            echo implode(',', $progress_rates);
                        ?>],
                    backgroundColor: 'rgba(54, 162, 235, 0.5)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    xAxes: [{
                        ticks: {
                            beginAtZero: true,
                            max: 100
                        }
                    }]
                },
                responsive: true,
                maintainAspectRatio: true
            }
        });

        // 두 번째 차트: 점수 달성율
        var scoreChart = new Chart(ctx2, {
            type: 'horizontalBar',
            data: {
                labels: [<?php echo implode(',', $names); ?>],
                datasets: [{
                    label: '점수 달성율 (%)',
                    data: [<?php
                            // 그래프용 점수 달성률 가져오기
                            $score_rates = [];
                            foreach ($result_teample as $row) {
                                $score_rates[] = $row['score_rate'];
                            }
                            echo implode(',', $score_rates);
                        ?>],
                    backgroundColor: 'rgba(255, 99, 132, 0.5)',
                    borderColor: 'rgba(255, 99, 132, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    xAxes: [{
                        ticks: {
                            beginAtZero: true,
                            max: 100
                        }
                    }]
                },
                responsive: true,
                maintainAspectRatio: true
            }
        });
    }

        // 테이블 정렬 함수
        function sortTable(n, th) {
            var table, rows, switching, i, x, y, shouldSwitch, dir, switchcount = 0;
            table = document.getElementById("teamTable");
            switching = true;
            dir = th.getAttribute("data-order") === "asc" ? "desc" : "asc";

            var icons = document.querySelectorAll('.sort-icon');
            icons.forEach(icon => icon.className = 'fas fa-sort sort-icon');
            th.querySelector('.sort-icon').className = dir === "asc" ? 'fas fa-sort-up sort-icon' : 'fas fa-sort-down sort-icon';
            th.setAttribute("data-order", dir);

            while (switching) {
                switching = false;
                rows = table.rows;
                for (i = 1; i < (rows.length - 1); i++) {
                    shouldSwitch = false;
                    x = rows[i].getElementsByTagName("TD")[n];
                    y = rows[i + 1].getElementsByTagName("TD")[n];

                    if (dir === "asc" && x.innerHTML.toLowerCase() > y.innerHTML.toLowerCase() || dir === "desc" && x.innerHTML.toLowerCase() < y.innerHTML.toLowerCase()) {
                        shouldSwitch = true;
                        break;
                    }
                }
                if (shouldSwitch) {
                    rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
                    switching = true;
                    switchcount++;
                }
            }
        }
    </script>
</body>

</html>

<?php
$result_teample->close();
$conn->close();
?>