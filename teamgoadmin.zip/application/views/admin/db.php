<?php
    // $server_name = servername();
    // $user_name = username();
    // $pass = password();
    // $db_name = dbname();

    $server_name = "localhost";
    $user_name = "root";
    $pass = " ";
    $db_name = "brandzipstage";

    $conn = mysqli_connect($server_name, $user_name, $pass, $db_name);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
?>  