<?php
// 설정파일 조정 필요
$kakaoConfig = array(
	// [수정해야함] 카카오 REST API 키값 , 카카오 디벨로퍼 > 내 애플리케이션 > 요약정보 > REST API값
	'client_id'=>'f68712d412f8857ad569079737aa2063',

	// [수정해야함] 카카오 디벨로퍼 > 내 애플리케이션 > 카카오로그인 > 보안
	'client_secret'=>'L6czD0J8ozg8B455GMNVGLNtQ3j0BBE5',

	// 로그인 인증 URL
	'login_auth_url'=>'https://kauth.kakao.com/oauth/authorize?response_type=code&client_id={client_id}&redirect_uri={redirect_uri}&state={state}',

	// 로그인 인증토큰 요청 URL
	'login_token_url'=>'https://kauth.kakao.com/oauth/token?grant_type=authorization_code&client_id={client_id}&redirect_uri={redirect_uri}&client_secret={client_secret}&code={code}',

	// 프로필정보 호출 URL 
	'profile_url'=>'https://kapi.kakao.com/v2/user/me',

	// [수정해야함] 로그인 인증 후 Callback url임 - 변경시 URL 수정해야함, 카카오 디벨로퍼 > 내 애플리케이션 > 카카오로그인 > Redirect URI
	'redirect_uri' => 'http://localhost/teamgoadmin/application/views/admin/kakaologin.php/'
	
	//'http'.(!empty($_SERVER['HTTPS']) ? 's':null).'://'.$_SERVER['HTTP_HOST'].'/oauth.php',
);


// 카카오 curl 
function curl_kakao1($url,$headers = array()){
	if(empty($url)){ return false ; }

	// URL에서 데이터를 추출 > 쿼리 생성
	$purl = parse_url($url); $postfields = array();
	if( !empty($purl['query']) && trim($purl['query']) != ''){
		$postfields = explode("&",$purl['query']);
	}

	$ch = curl_init(); 
	curl_setopt($ch, CURLOPT_URL, $url); 
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0); 
	curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']); 
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
	curl_setopt($ch, CURLOPT_POST, 1); 
	curl_setopt($ch, CURLOPT_POSTFIELDS, $postfields); 
	if( count($headers) > 0){ 
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers); 
	}

	ob_start(); // prevent any output
	$data = curl_exec($ch); 
	ob_end_clean(); // stop preventing output

	if (curl_error($ch)){ return false;} 

	curl_close($ch); 
	return $data;		
}