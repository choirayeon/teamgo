<!DOCTYPE html>
<html lang="ko">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style type="text/css">
        * {
            box-sizing: border-box;
        }

        body {
            font-family: "Montserrat", sans-serif;
            margin: 0 auto;
            padding: 0;
        }

        .wrapper {
            width: 100%;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background: #ebecf0;
            overflow: hidden;
        }

        .container {
            border-radius: 10px;
            box-shadow: -5px -5px 10px #fff, 5px 5px 10px #babebc;
            position: absolute;
            width: 500px;
            min-height: 480px;
            overflow: hidden;
        }

        form {
            background: #ebecf0;
            display: flex;
            flex-direction: column;
            padding: 0 50px;
            height: 100%;
            justify-content: center;
            align-items: center;
        }

        form input {
            background: #eee;
            padding: 16px;
            margin: 8px 0;
            width: 85%;
            border: 0;
            outline: none;
            border-radius: 20px;
            box-shadow: inset 7px 2px 10px #babebc, inset -5px -5px 12px #fff;
        }

        button {
            border-radius: 20px;
            border: none;
            outline: none;
            font-size: 12px;
            font-weight: bold;
            padding: 15px 45px;
            margin: 14px;
            letter-spacing: 1px;
            text-transform: uppercase;
            cursor: pointer;
            transition: transform 80ms ease-in;
        }

        .form_btn {
            box-shadow: -5px -5px 10px #fff, 5px 5px 8px #babebc;
        }

        .form_btn:active {
            box-shadow: inset 1px 1px 2px #babebc, inset -1px -1px 2px #fff;
        }

        .overlay_btn {
            background-color: #2C3E50;
            color: #fff;
            box-shadow: -5px -5px 10px #496785, 5px 5px 8px #1C2833;
        }

        .sign-in-container {
            position: absolute;
            left: 0;
            width: 100%;
            height: 100%;
        }

        form h1 {
            font-size: 30pt;
            font-weight: bold;
            margin: 0;
            color: #000;
        }

        p {
            font-size: 16px;
            font-weight: bold;
            letter-spacing: 0.5px;
            margin: 20px 0 30px;
        }

        span {
            font-size: 12px;
            color: #707070;
            letter-spacing: 0.5px;
            margin-bottom: 10px;
        }
    </style>
</head>

<body>
    <div class="wrapper">
        <img src="../../../garage/image/logo.png" style="position:absolute; top: 70px; width: 350px; height: auto;">
        <div class="container">
            <div class="sign-in-container">
                <form action="/teamgoadmin/application/views/admin/login_ok.php" method="post">
                    <img src="/attendance/images/Login - MarkMaker Logo.svg" style="width: 200px; height: auto;">
                    <!-- 학번 입력란 -->
                    <input type="id" name="id" placeholder="ID(e-mail)" class="form-control">

                    <!-- 비밀번호 입력란 -->
                    <input type="password" name="pw" placeholder="Password" class="form-control">

                    <!-- 학번 입력란에 값이 들어가 있다면 --->
                    <?php if (isset($errors['id'])): ?>
                        <div style="color:red"><?= $errors['id'] ?></div>
                    <?php endif; ?>

                    <br>
                    <button type="submit" value="로그인" class="form_btn">로그인</button>
                    <?php
                    // [config.php를 수정해야함] 카카오 API 환경설정 파일 
                    include_once dirname(__FILE__) . "/config.php";

                    // 정보치환 
                    $replace = array(
                        '{client_id}' => $kakaoConfig['client_id'],
                        '{redirect_uri}' => $kakaoConfig['redirect_uri'],
                        '{state}' => md5(mt_rand(111111111, 999999999)),
                    );
                    setcookie('state', $replace['{state}'], time() + 300); // 300 초동안 유효

                    $login_auth_url = str_replace(array_keys($replace), array_values($replace), $kakaoConfig['login_auth_url']);
                    ?>

                    <div class="kakao-login">
                        <a href="<?php echo $login_auth_url ?>" id="kakao-login">
                            <img alt="resource preview" src="https://k.kakaocdn.net/14/dn/btroDszwNrM/I6efHub1SN5KCJqLm1Ovx1/o.jpg">
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>

</html>