<?php
session_cache_expire(360);
session_start();

if (!isset($_SESSION['id'])) {
    echo "<script>alert('로그인 후 이용해 주세요.');</script>";
    echo "<script>location.replace('../admin/login_admin.php');</script>";
    exit;
}

include "../../config/db_connect.php";

$id = $_SESSION['id'];

$stmt = $conn->prepare("SELECT * FROM user WHERE id = ?");
$stmt->bind_param("s", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $user_info = $result->fetch_assoc();
} else {
    echo "<script>alert('사용자 정보를 가져올 수 없습니다.');</script>";
    exit;
}

$password = $user_info['password'];
?>

<!DOCTYPE html>
<html lang="ko">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>teamgo</title>
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet">
    <link href="/teamgoadmin/css/styles.css" rel="stylesheet">
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
</head>

<body class="sb-nav-fixed">
    <?php include $_SERVER['DOCUMENT_ROOT'] . '/teamgoadmin/application/views/include/top_menu.php'; ?>
    <div id="layoutSidenav">
        <?php include $_SERVER['DOCUMENT_ROOT'] . '/teamgoadmin/application/views/include/side_menu.php'; ?>

        <div id="layoutSidenav_content" style="padding-top: 20px; height: auto; background-color: rgb(224, 224, 224);">
            <main>
                <div style="width:600px;">
                    <div class="card shadow">
                        <div class="card-body">
                            <table class="table table-bordered">
                                <tr>
                                    <td>사용자 유형</td>
                                    <td>
                                        <input type="text" name="user_type" class="form-control" readonly="true" style="background: #D1D1D1;" value="교수" />
                                    </td>
                                </tr>
                                <tr>
                                    <td>아이디</td>
                                    <td>
                                        <input type="text" name="id" id="id" class="form-control" readonly="true" style="background: #D1D1D1;" value="<?php echo $user_info['id']; ?>" />
                                    </td>
                                </tr>
                                <tr>
                                    <td>이름</td>
                                    <td>
                                        <input type="text" name="name" id="name" class="form-control" readonly="true" style="background: #D1D1D1;" value="<?php echo $user_info['name']; ?>" />
                                    </td>
                                </tr>
                                <tr>
                                    <td>닉네임</td>
                                    <td>
                                        <input type="text" name="nickname" class="form-control" readonly="true" style="background: #D1D1D1;" value="<?php echo $user_info['nickname']; ?>" />
                                    </td>
                                </tr>
                            </table>

                            <div style="padding-top: 30px; text-align: center;">
                                <form id="passwordChangeForm" action="../admin/modify_pass_admin.php" method="post" style="display: inline;">
                                    <button type="button" class="btn btn-secondary" style="margin-right: 10px;" onclick="checkPassword()">비밀번호 변경하기</button>
                                </form>

                                <form action="../admin/modify_admin.php" method="post" style="display: inline;">
                                    <button type="submit" class="btn btn-primary" style="background: #2C3E50; border:#2C3E50;">회원정보 수정하기</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script>

    <script>
        function checkPassword() {
            var password = "<?php echo $password; ?>";

            if (password === '' || password === 'null') {
                alert("카카오로 로그인한 경우 비밀번호 수정이 불가합니다.");
            } else {
                document.getElementById('passwordChangeForm').submit();
            }
        }
    </script>
</body>

</html>