<div id="layoutSidenav_nav">
   <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
      <div class="sb-sidenav-menu">
         <div class="sb-sidenav-footer">
            <div><?= htmlspecialchars($_SESSION['name']) ?>님</div>
            <div>환영합니다!</div>
         </div>
         <div class="nav">
            <a class="nav-link collapsed" href="../admin/main_info_admin.php"> 회원정보</a>
            <a class="nav-link collapsed" href="../admin/main_team_admin.php"> 팀목록</a>
         </div>
      </div>
   </nav>
</div>

<script>
   document.addEventListener('DOMContentLoaded', function() {
      var sidebarToggle = document.getElementById('sidebarToggle');
      var layoutSidenavNav = document.getElementById('layoutSidenav_nav');
      var body = document.body;

      sidebarToggle.addEventListener('click', function() {
         layoutSidenavNav.classList.toggle('collapsed');
         body.classList.toggle('sb-sidenav-toggled');
      });
   });
</script>

<style>
   .sb-sidenav {
      background-color: #158143;
      color: #114225;
          /* 글자 굵게 */
      font-weight: bold;
   }

   .sb-sidenav-footer {
      background-color: #97CC97 !important;
   }

   .sb-sidenav.collapsed {
      transform: translateX(-250px);
      transition: transform 0.3s ease;
      background-color: #158143;
   }

   body.sb-sidenav-toggled .sb-sidenav {
      transform: translateX(0);
      transition: transform 0.3s ease;
   }

   .sb-sidenav.collapsed {
      transform: translateX(-250px);
      transition: transform 0.3s ease;
   }

   body.sb-sidenav-toggled .sb-sidenav {
      transform: translateX(0);
      transition: transform 0.3s ease;
   }
</style>